# 违约用户风险预测

本次参加的是四大赛题中的[用户贷款风险预测（算法竞赛）](https://aichallenge.msxf.com/#/subject/D/info)


## **队伍简介** ##
队伍名“我只吃两个剩下的都给你“。我们四个队友都是同一个实验室的同学。 最终线上排名第一。
![image](https://github.com/chenkkkk/User-loan-risk-prediction/blob/master/%E6%9C%80%E7%BB%88%E6%88%90%E7%BB%A9%E6%88%AA%E5%9B%BE.png)
# 任务
马上金融平台提供了近7万贷款用户的基本身份信息、消费行为、银行还款等数据信息，需要参赛者以此建立准确的风险控制模型，来预测用户是否会逾期还款。

## **数据** ##
链接：https://pan.baidu.com/s/1dFX1X4Y7KZWrAkxzE2nzbA 密码：6rwo

# 代码说明
见决赛文档和答辩ppt
