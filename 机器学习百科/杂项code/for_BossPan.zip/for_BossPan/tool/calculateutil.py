# -*- coding: utf-8 -*-
# @Time    :
# @Author  :
# @Email   :
# @File    : calculateutil.py
# @Software: PyCharm
# @Description:
import os
import pandas as pd
import numpy as np
from datetime import datetime
from sklearn.linear_model import LinearRegression


def map_flatten_df(map_value):
    df_value = pd.DataFrame()
    for key, value in map_value.items():
        category_list = []
        for i in range(0, len(value)):
            category_list.append(key)
        tmp_dataframe = pd.DataFrame({'value': value, 'category': category_list})
        df_value = pd.concat([df_value, tmp_dataframe], ignore_index=True)
    return df_value


def remove_multi_std(all_value, mult=3):
    tb_mean = np.mean(np.array(all_value))
    tb_std = np.std(np.array(all_value))
    tmp_remove = []
    for value in all_value:
        if value-tb_mean > tb_std*mult or value == 0:   # n > 0
            tmp_remove.append(value)
    for value in tmp_remove:
        all_value.remove(value)
    return all_value


def linear_func(l):
    x_axis = []
    for i in range(1, len(l) + 1):
        x_axis_i = [i, i]
        x_axis.append(x_axis_i)
    x_axis = np.array(x_axis)
    l_new = []
    for i in range(len(l)):
        l_i = float(l[i])
        l_new.append(l_i)
    l_new = np.array(l_new)
    regr = LinearRegression()
    regr.fit(x_axis, l_new)
    k = regr.coef_
    k = k[0]
    return k


def conv_feature(window, factors, conv_func=linear_func):
    res = []
    for i in range(window - 1, len(factors)):
        res.append(conv_func(factors[i - window + 1: i]))
    return res


def make_path(path):
    if not os.path.exists(path):
        os.makedirs(path)


def datetime_to_str(start_time, end_time):
    if isinstance(start_time, datetime):
        start_time = start_time.strftime('%Y-%m-%d %H:%M:%S')
        end_time = end_time.strftime('%Y-%m-%d %H:%M:%S')
    return start_time, end_time


def str_to_time(start_time, end_time):
    if isinstance(start_time, str):
        start_time = datetime.strptime(start_time, '%Y-%m-%d %H:%M:%S')
        end_time = datetime.strptime(end_time, '%Y-%m-%d %H:%M:%S')
    return start_time, end_time
