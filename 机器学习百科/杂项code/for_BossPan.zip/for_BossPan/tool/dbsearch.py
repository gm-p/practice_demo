# -*- coding: utf-8 -*-
# @Time    :
# @Author  :
# @Email   :
# @File    : dbsearch.py
# @Software: PyCharm
# @Description:
import time
import pandas as pd
from tool import configutil,calculateutil
import os
os.environ['NLS_LANG'] = 'SIMPLIFIED CHINESE_CHINA.UTF8'
os.environ['path'] = 'D:/Soft/Navicat 12 for Oracle/instantclient_11_2'
import cx_Oracle

def get_conn():
    conn_info = configutil.get_oracle_param()
    conn = cx_Oracle.connect(conn_info)
    return conn


def get_windfarms(conn):
    search_sql = "SELECT C.NAME,C.ID FROM CMS.EC_WIND_FARM C"
    search_res = pd.read_sql(search_sql, conn)
    windfarm_dict = dict(zip(search_res.NAME, search_res.ID))
    return windfarm_dict


def get_tubines(conn, windfarm_id):
    search_sql = "SELECT A.NAME, A.ID FROM CMS.CMS_TURBINE A WHERE A.WIND_FARM_ID = '%s'" % (windfarm_id,)
    search_res = pd.read_sql(search_sql, conn)
    turbine_dict = dict(zip(search_res.NAME, search_res.ID))
    return turbine_dict


def get_components(conn, tb_id):
    search_sql = "SELECT D.NODE_TYPE, D.ID FROM CMS.CMS_COMPONENT D WHERE D.TURBINE_ID = '%s'" % (tb_id, )
    search_res = pd.read_sql(search_sql, conn)
    component_dict = dict(zip(search_res.NODE_TYPE, search_res.ID))
    return component_dict


def get_meanpoints(conn, tb_id, cp_id):
    search_sql = ("SELECT C.NAME, C.ID FROM CMS.CMS_MEASURE_POINTS C WHERE C.COMPONENT_ID = '%s' \
                  AND C.TURBINE_ID = '%s'") % (cp_id, tb_id)
    search_res = pd.read_sql(search_sql, conn)
    meanpoint_dict = dict(zip(search_res.NAME, search_res.ID))
    return meanpoint_dict


def get_task_parents(conn, tb_id, mp_id):
    search_sql = ("	SELECT A.NAME, A.ID FROM CMS.CMS_MEASURE_TASK A WHERE A.MEASURE_POINTS_ID = '%s'\
                  AND A.TURBINE_ID = '%s' AND A.PARENT_ID IS NULL") % (mp_id, tb_id)
    search_res = pd.read_sql(search_sql, conn)
    task_parent_dict = dict(zip(search_res.NAME, search_res.ID))
    return task_parent_dict


def get_task_names(conn, tb_id, mp_id, task_parent_id):
    search_sql = ("SELECT A.NAME, A.ID FROM CMS.CMS_MEASURE_TASK A \
                 WHERE A.MEASURE_POINTS_ID = '%s' AND TURBINE_ID = '%s'\
                 AND A.PARENT_ID = '%s'") % (mp_id, tb_id, task_parent_id)
    search_res = pd.read_sql(search_sql, conn)
    task_name_dict = dict(zip(search_res.NAME, search_res.ID))
    return task_name_dict


def get_task_value(conn, wf, tb, cp, mp, task_parent, task_name,
                   min_gs, max_gs, start_time, end_time):
    start_time, end_time = calculateutil.str_to_time(start_time, end_time)
    search_sql = ("SELECT A.VALUE, A.SAMPLING_DATE, A.GENERATOR_SPEED FROM CMS.CMS_TREND_DATA A WHERE A.TASK_ID IN( \
                   SELECT B.ID FROM CMS.CMS_MEASURE_TASK B WHERE B.MEASURE_POINTS_ID IN ( \
                   SELECT C.ID FROM CMS.CMS_MEASURE_POINTS C WHERE C.COMPONENT_ID IN ( \
                   SELECT D.ID FROM CMS.CMS_COMPONENT D WHERE D.TURBINE_ID IN ( \
                   SELECT E.ID FROM CMS.CMS_TURBINE E WHERE E.WIND_FARM_ID IN ( \
                   SELECT F.ID FROM CMS.EC_WIND_FARM F WHERE F.NAME IN '%s' \
                   ) AND E.NAME = '%s' \
                   ) AND D.NODE_TYPE IN ('%s') \
                   ) AND C.NAME IN ('%s') \
                   ) AND  B.NAME IN ('%s')  AND B.PARENT_ID IN ( \
                   SELECT BB.ID FROM CMS.CMS_MEASURE_TASK BB WHERE BB.NAME = '%s')\
                   )AND A.SAMPLING_DATE BETWEEN TO_DATE('%s', 'YYYY-MM-DD HH24:MI:SS') \
                   AND TO_DATE('%s', 'YYYY-MM-DD HH24:MI:SS') AND A.GENERATOR_SPEED BETWEEN %d AND %d ORDER BY A.SAMPLING_DATE DESC") % \
                  (wf, tb, cp, mp, task_name, task_parent, start_time, end_time, min_gs, max_gs)
    search_res = pd.read_sql(search_sql, conn)
    search_res.columns = ['value', 'timestamp', 'genspeed']
    return search_res


def get_task_update_time(conn, wf, tb, cp, mp, task_parent, task_name):
    search_sql = ("SELECT B.LAST_UPDATE AS LAST_UPDATE FROM CMS.CMS_MEASURE_TASK B WHERE B.MEASURE_POINTS_ID IN ( \
                      SELECT C.ID FROM CMS.CMS_MEASURE_POINTS C WHERE C.COMPONENT_ID IN ( \
                      SELECT D.ID FROM CMS.CMS_COMPONENT D WHERE D.TURBINE_ID IN ( \
                      SELECT E.ID FROM CMS.CMS_TURBINE E WHERE E.WIND_FARM_ID IN ( \
                      SELECT F.ID FROM CMS.EC_WIND_FARM F WHERE F.NAME IN '%s' \
                      ) AND E.NAME = '%s' \
                      ) AND D.NODE_TYPE IN ('%s') \
                      ) AND C.NAME IN ('%s') \
                      ) AND  B.NAME IN ('%s')  AND B.PARENT_ID IN ( \
                        SELECT BB.ID FROM CMS.CMS_MEASURE_TASK BB WHERE BB.NAME = '%s')") % \
                 (wf, tb, cp, mp, task_name, task_parent)

    search_res = pd.read_sql(search_sql, conn)
    last_update = search_res['LAST_UPDATE'][0]
    return last_update


def get_T_update_time(conn, wf, tb, cp, mp):
    search_sql = ("SELECT B.LAST_UPDATE AS LAST_UPDATE FROM CMS.CMS_MEASURE_TASK B WHERE B.MEASURE_POINTS_ID IN ( \
                      SELECT C.ID FROM CMS.CMS_MEASURE_POINTS C WHERE C.COMPONENT_ID IN ( \
                      SELECT D.ID FROM CMS.CMS_COMPONENT D WHERE D.TURBINE_ID IN ( \
                      SELECT E.ID FROM CMS.CMS_TURBINE E WHERE E.WIND_FARM_ID IN ( \
                      SELECT F.ID FROM CMS.EC_WIND_FARM F WHERE F.NAME IN '%s' \
                      ) AND E.NAME = '%s' \
                      ) AND D.NODE_TYPE IN ('%s') \
                      ) AND C.NAME IN ('%s') \
                      ) AND  B.NODE_TYPE = 'TASK_T' AND B.PARENT_ID IS NULL") % \
                 (wf, tb, cp, mp)
    search_res = pd.read_sql(search_sql, conn)
    last_update = search_res['LAST_UPDATE'][0]
    return last_update


def get_task_value_nogs(conn, wf, tb, cp, mp, task_parent, task_name, start_time, end_time):
    tart_time, end_time = calculateutil.str_to_time(start_time, end_time)
    search_sql = ("SELECT A.VALUE, A.SAMPLING_DATE, A.GENERATOR_SPEED FROM CMS.CMS_TREND_DATA A WHERE A.TASK_ID IN( \
                   SELECT B.ID FROM CMS.CMS_MEASURE_TASK B WHERE B.MEASURE_POINTS_ID IN ( \
                   SELECT C.ID FROM CMS.CMS_MEASURE_POINTS C WHERE C.COMPONENT_ID IN ( \
                   SELECT D.ID FROM CMS.CMS_COMPONENT D WHERE D.TURBINE_ID IN ( \
                   SELECT E.ID FROM CMS.CMS_TURBINE E WHERE E.WIND_FARM_ID IN ( \
                   SELECT F.ID FROM CMS.EC_WIND_FARM F WHERE F.NAME IN '%s' \
                   ) AND E.NAME = '%s' \
                   ) AND D.NODE_TYPE IN ('%s') \
                   ) AND C.NAME IN ('%s') \
                   ) AND  B.NAME IN ('%s')  AND B.PARENT_ID IN ( \
                   SELECT BB.ID FROM CMS.CMS_MEASURE_TASK BB WHERE BB.NAME = '%s')\
                   )AND A.SAMPLING_DATE BETWEEN TO_DATE('%s', 'YYYY-MM-DD HH24:MI:SS') \
                   AND TO_DATE('%s', 'YYYY-MM-DD HH24:MI:SS') ORDER BY A.SAMPLING_DATE DESC") % \
                  (wf, tb, cp, mp, task_name, task_parent, start_time, end_time)
    search_res = pd.read_sql(search_sql, conn)
    search_res.columns = ['value', 'timestamp', 'genspeed']
    return search_res


def get_wf_netinfo(conn, wf_names):
    search_sql = 'SELECT A.name as name, B.EXPIRE_DAYS as net_label FROM CMS.EC_WIND_FARM  A, CMS.CMS_EXPIRE_DAYS B WHERE A.ID = B.WIND_FARM_ID AND A.NAME IN (\''+ '\',\''.join(wf_names) +'\')'
    search_res = pd.read_sql(search_sql, conn)
    return search_res


if __name__ == "__main__":
    print(get_conn())
    conn = get_conn()
    wf_names = ['云南雪邦山二期', '安徽巢湖', '安徽巢湖二期']
    get_wf_netinfo(conn,wf_names)