# -*- coding: utf-8 -*-
# @Time    :
# @Author  :
# @Email   :
# @File    : configutil.py
# @Software: PyCharm
# @Description:
from configparser import ConfigParser
import os

# print(os.getcwd())
relative_path = "D:\\workspace\\cms_201810929"
scp = ConfigParser()
scp.read(relative_path + '/data/config.ini', encoding='utf-8')


def get_oracle_param():
    conn_info = scp.get('oracle_param', 'conn_info')
    return conn_info


def get_data_path(task_name):
    task_config_path = '{}_data_path'.format(task_name.split("_")[-1])
    task_data_path = scp.get('data_path', task_config_path)
    return task_data_path


def get_photo_path(task_name):
    task_config_path = '{}_photo_path'.format(task_name.split("_")[-1])
    task_photo_path = scp.get('photo_path', task_config_path)
    return task_photo_path


def get_csv_path(task_name):
    task_config_path = '{}_csv_path'.format(task_name.split("_")[-1])
    task_csv_path = scp.get('csv_path', task_config_path)
    return task_csv_path


def get_minmax_speed():
    min_speed = int(scp.get('gen_speed', 'min_speed'))
    max_speed = int(scp.get('gen_speed', 'max_speed'))
    return min_speed, max_speed


def get_save_data_time():
    save_month = int(scp.get("save_data_time", "save_month"))
    return save_month


def get_windfarams():
    all_wf = scp.get("windfarms", "windfarm")
    wf_list = all_wf.split("，")
    return wf_list
