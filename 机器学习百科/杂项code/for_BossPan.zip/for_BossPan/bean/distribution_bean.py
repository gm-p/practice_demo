# -*- coding: utf-8 -*-
# @Time    :
# @Author  :
# @Email   :
# @File    : distribution_bean.py
# @Software: PyCharm
# @Description:
from collections import defaultdict
from tool import calculateutil
from action import distribution_plot


class DistributionBean:
    def __init__(self, task_bean):
        self.task_bean = task_bean

    def get_distribution_data(self, date_inter=None, gs_inter=None):
        distribut_value_dict = defaultdict(dict)
        for index, row in self.task_bean.task_relation_df.iterrows():
            wf, tb, cp, mp, task_parent, task_name = row
            try:
                key_path, file_path, value_list = self.task_bean.get_value_list_file(row, date_inter, gs_inter)
            except:
                continue
            distribut_value_dict[key_path].setdefault(wf, list())
            distribut_value_dict[key_path][wf].extend(value_list)
        return distribut_value_dict

    def make_distribution_plot(self, distribut_value_dict, distribution_plots):
        for key_path, wf_value_dict in distribut_value_dict.iteritems():
            wf_value_df = calculateutil.map_flatten_df(wf_value_dict)
            for plot_kind in distribution_plots:
                distribution_plot.plot_sns_plot(wf_value_df, key_path, self.task_bean.task_name, plot_kind)
        print("distribution plot ok!")