# -*- coding: utf-8 -*-
# @Time    :
# @Author  :
# @Email   :
# @File    : trend_bean.py
# @Software: PyCharm
# @Description:
import os
import pickle
import numpy as np
from collections import defaultdict

from action import trend_plot
from tool import configutil
from bean import fault_bean


class TrendBean:
    def __init__(self, task_bean):
        self.task_bean = task_bean

    def get_trend_value_data(self, date_inter=None, gs_inter=None):
        trend_value_dict = defaultdict(dict)
        for index, row in self.task_bean.task_relation_df.iterrows():
            wf, tb, cp, mp, task_parent, task_name = row
            try:
                key_path, file_path, value_list = self.task_bean.get_value_list_file(row, date_inter, gs_inter)
            except:
                continue
            trend_value_dict[key_path].setdefault(tb, list())
            trend_value_dict[key_path][tb].append(value_list)
        return trend_value_dict

    def make_trend_value_data(self, trend_value_dict):
        for key_path in trend_value_dict.keys():
            trend_plot.plot_trend_decomposition(trend_value_dict[key_path], key_path, self.task_bean.task_name)
        print("plot trend value ok!")

    def get_trend_meanstd_data(self, fault_tb_dict, date_inter=None, gs_inter=None):
        trend_mean_dict = defaultdict(dict)
        trend_std_dict = defaultdict(dict)
        for index, row in self.task_bean.task_bean.task_relation_df.iterrows():  # instead fault_tb_dict
            wf, tb, cp, mp, task_parent, task_name = row
            key_path = '/'.join([cp, mp, task_parent, task_name, wf])
            open_path = configutil.get_data_path(self.task_bean.task_bean.task_name) + '/'.join(row[:-1])
            file_path = open_path + '/' + task_name
            if not os.path.exists(file_path) and not fault_bean.is_fault_tb(fault_tb_dict, row):
                continue
            open_file = open(open_path + '/' + task_name, 'rb')
            task_data_df = pickle.load(open_file)
            del task_data_df
            filter_data_df = self.task_bean.filter_df(task_data_df, date_inter, gs_inter)
            window_value = trend_plot.split_trend_date(filter_data_df, windows=7, interval=3)
            mean_list = map(lambda x: np.array(x).mean(), window_value)
            std_list = map(lambda x: np.array(x).std(), window_value)
            trend_mean_dict[key_path].setdefault(tb, list())
            trend_std_dict[key_path].setdefault(tb, list())
            trend_mean_dict[key_path][tb].append(mean_list)
            trend_std_dict[key_path][tb].append(std_list)
        return trend_mean_dict, trend_std_dict

    def make_trend_meanstd_data(self, trend_mean_dict, trend_std_dict):
        for key_path in trend_mean_dict.keys():
            trend_plot.plot_mean_std_plot(trend_mean_dict[key_path], trend_std_dict[key_path],
                                          key_path, self.task_bean.task_name)
        print("plot trend meanstd ok !")