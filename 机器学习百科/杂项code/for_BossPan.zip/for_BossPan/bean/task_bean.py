# -*- coding: utf-8 -*-
# @Time    :
# @Author  :
# @Email   :
# @File    : task_bean.py
# @Software: PyCharm
# @Description:
import pickle
from datetime import datetime, timedelta

from tool import dbsearch, configutil, calculateutil
from bean.relationbean import RelationShip


class TaskStatistics:
    def __init__(self, cp, mp_like, parent_like, task_name, stat_day=28, gs_inter=(1400, 1800)):
        self.cp = cp
        self.mp_like = mp_like
        self.parent_like = parent_like
        self.task_name = task_name
        self.task_relation_df = RelationShip().get_task_relation_df(cp, mp_like, parent_like, task_name)
        self.gs_inter = gs_inter
        end_time = datetime.now()
        start_time = end_time - timedelta(days=stat_day)
        start_time, end_time = calculateutil.datetime_to_str(start_time, end_time)
        self.data_inter = (start_time, end_time)

    def get_task_relation_df(self):
        return self.task_relation_df

    def set_task_relation_df(self, task_relation_df):
        self.task_relation_df = task_relation_df

    def save_task_data(self, wf_name=None, gs_bool=False):
        conn = dbsearch.get_conn()
        min_gs, max_gs = configutil.get_minmax_speed()
        start_time, end_time = self.data_inter
        for index, row in self.task_relation_df.iterrows():
            # print("save_task_data: row{\n %s}" % row)
            wf, tb, cp, mp, task_parent, task_name = row
            if wf_name and wf != wf_name:
                continue
            if gs_bool:
                task_data_df = dbsearch.get_task_value(conn, wf, tb, cp, mp, task_parent,
                                                       task_name, min_gs, max_gs, start_time, end_time)
            else:
                task_data_df = dbsearch.get_task_value_nogs(conn, wf, tb, cp, mp, task_parent,
                                                            task_name, start_time, end_time)
            if task_data_df.empty: continue
            save_path = (configutil.get_data_path(self.task_name) + '/'.join(row[:-1]))
            calculateutil.make_path(save_path)
            pickle.dump(task_data_df, open(save_path + '/' + task_name, 'wb'), 2)

    def load_raw_data_file(self, row):
        wf, tb, cp, mp, task_parent, task_name = row
        key_path = '/'.join([cp, mp, task_parent, task_name])
        open_path = configutil.get_data_path(self.task_name) + '/'.join(row[:-1])
        file_path = open_path + '/' + task_name
        try:
            open_file = open(open_path + '/' + task_name, 'rb')
        except FileNotFoundError:
            raise FileNotFoundError("FileNotFoundError")
        else:
            task_data_df = pickle.load(open_file)
            if task_data_df.empty:
                raise ValueError()
        return key_path, file_path, task_data_df

    def filter_raw_data(self, task_data_df, date_inter, gs_inter):
        filter_data_df = self._filter_df(task_data_df, date_inter, gs_inter)
        return filter_data_df

    def get_value_list_file(self, row, date_inter=None, gs_inter=None):
        key_path, file_path, task_data_df = self.load_raw_data_file(row)
        filter_data_df = self.filter_raw_data(task_data_df, date_inter, gs_inter)
        del task_data_df
        value_list = calculateutil.remove_multi_std(list(filter_data_df['value']))
        if not value_list:
            raise ValueError()
        return key_path, file_path, value_list

    def _filter_df(self, value_df, date_inter=None, gs_inter=None):
        gs_data_df = value_df[(gs_inter[0] < value_df.genspeed) & (value_df.genspeed < gs_inter[1])] \
            if gs_inter else value_df
        timestamp_data_df = gs_data_df[(date_inter[0] < gs_data_df.timestamp) & (gs_data_df.timestamp < date_inter[1])] \
            if date_inter else gs_data_df
        timestamp_data_df = timestamp_data_df.sort_values(by='timestamp', ascending=False)
        return timestamp_data_df

    def __str__(self):
        return "Task is: %s ==> %s ==> %s ==> %s " % (self.cp, self.mp_like, self.parent_like, self.task_name)
