# -*- coding: utf-8 -*-
# @Time    :
# @Author  :
# @Email   :
# @File    : BDR_bean.py
# @Software: PyCharm
# @Description: BDF/RMS
import pandas as pd
import pickle
from tool import configutil, calculateutil
from bean.task_bean import TaskStatistics

MB_BDF_task = TaskStatistics("MB", "主轴", "ENV", "BDF")
MB_RMS_task = TaskStatistics("MB", "主轴", "ENV", "RMS")
relative_path = configutil.relative_path

def get_raw_data_file(obj, name):
    task_relation_df = obj.get_task_relation_df()
    raw_data = dict()
    for index, row in task_relation_df.iterrows():
        wf, tb, cp, mp, task_parent, task_name = row
        try:
            key_path, file_path, task_data_df = obj.load_raw_data_file(row)
        except:
            continue
        raw_key = '/'.join([wf, tb, cp, mp, task_parent])
        data_df = task_data_df.drop(['genspeed'], axis=1)
        data_df = data_df[data_df.value != 0]
        data_df.columns = [name, 'timestamp']
        raw_data[raw_key] = data_df
    return raw_data


def combine_raw_data(raw_data_1, raw_data_2, name):
    for raw_key in raw_data_1.keys():
        data_df_1 = raw_data_1[raw_key]
        if raw_key not in raw_data_2.keys(): continue
        data_df_2 = raw_data_2[raw_key]
        data_df = pd.merge(data_df_1, data_df_2, on=['timestamp'])
        if not list(data_df['BDF']) or not list(data_df['RMS']):
            print("wrong"+raw_key)
        data_df['value'] = data_df['BDF']/data_df['RMS']
        save_path = (configutil.get_data_path(name) + raw_key)
        calculateutil.make_path(save_path)
        pickle.dump(data_df, open(save_path + '/' + name, 'wb'), 2)


def save_relation_df(raw_data_1, raw_data_2, filename_list):
    relation_list = list()
    for raw_key in raw_data_1.keys():
        if raw_key not in raw_data_2.keys(): continue
        tmp_list = raw_key.split("/")
        tmp_list.append(filename_list[-1])
        relation_list.append(tmp_list)
    relation_df = pd.DataFrame(relation_list, columns=['wf', 'tb', 'cp', 'mp', 'task_parent', 'task_name'])
    file_name = '_'.join(filename_list)
    pickle.dump(relation_df, open(relative_path + '/data/task_df/' +  file_name +"_relation_df", 'wb'), 2)


if __name__ == "__main__":
    raw_data_1 = get_raw_data_file(MB_BDF_task, 'BDF')
    raw_data_2 = get_raw_data_file(MB_RMS_task, 'RMS')
    combine_raw_data(raw_data_1, raw_data_2, 'BDR')
    save_relation_df(raw_data_1, raw_data_2,["主轴", "ENV", "BDR"])

