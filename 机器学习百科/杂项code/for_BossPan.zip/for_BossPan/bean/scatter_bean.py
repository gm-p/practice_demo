# -*- coding: utf-8 -*-
# @Time    :
# @Author  :
# @Email   :
# @File    : scatter_bean.py
# @Software: PyCharm
# @Description:
import csv
from copy import deepcopy
import numpy as np
from collections import defaultdict

from action import scatter_plot
from tool import calculateutil
from tool import configutil


class ScatterBean:
    def __init__(self, task_bean):
        self.task_bean = task_bean

    def get_scatter_meanstd(self, date_inter=None, gs_inter=None):
        task_mean_dict = defaultdict(dict)
        task_std_dict = defaultdict(dict)
        task_tb_dict = defaultdict(dict)
        for index, row in self.task_bean.task_relation_df.iterrows():
            wf, tb, cp, mp, task_parent, task_name = row
            try:
                key_path, file_path, value_list = self.task_bean.get_value_list_file(row, date_inter, gs_inter)
            except Exception:
                continue
            task_mean_dict[key_path].setdefault(wf, list())
            task_std_dict[key_path].setdefault(wf, list())
            task_tb_dict[key_path].setdefault(wf, list())
            task_mean_dict[key_path][wf].append(np.mean(np.array(value_list)))
            task_std_dict[key_path][wf].append(np.std(np.array(value_list)))
            task_tb_dict[key_path][wf].append(tb)
        #print("get scatter data ok!")
        return task_tb_dict, task_mean_dict, task_std_dict

    def get_scatter_feature(self, date_inter=None, gs_inter=None):
        task_mean_dict = defaultdict(dict)
        task_std_dict = defaultdict(dict)
        task_tb_dict = defaultdict(dict)
        task_slope_dict = defaultdict(dict)
        for index, row in self.task_bean.task_relation_df.iterrows():
            wf, tb, cp, mp, task_parent, task_name = row
            try:
                key_path, file_path, value_list = self.task_bean.get_value_list_file(row, date_inter, gs_inter)
            except:
                continue
            task_mean_dict[key_path].setdefault(wf, list())
            task_std_dict[key_path].setdefault(wf, list())
            task_tb_dict[key_path].setdefault(wf, list())
            task_slope_dict[key_path].setdefault(wf, list())
            task_mean_dict[key_path][wf].append(np.mean(np.array(value_list)))
            task_std_dict[key_path][wf].append(np.std(np.array(value_list)))
            task_slope_dict[key_path][wf].append(calculateutil.linear_func(value_list))
            task_tb_dict[key_path][wf].append(tb)
        #print("get scatter data ok!")
        return task_tb_dict, task_mean_dict, task_std_dict, task_slope_dict

    def get_tb_mean_std(self, task_tb_dict, task_mean_dict, task_std_dict):
        mean_std_dict = defaultdict(dict)
        for key_path in task_tb_dict.keys():
            for wf in task_tb_dict[key_path]:
                mean_std_dict[key_path].setdefault(wf, dict())
                tb_list = task_tb_dict[key_path][wf]
                mean_list = task_mean_dict[key_path][wf]
                std_list = task_std_dict[key_path][wf]
                for i in range(0, len(tb_list)):
                    mean_std_dict[key_path][wf][tb_list[i]] = (mean_list[i], std_list[i])
        return mean_std_dict

    def make_scatter_plot(self, task_tb_dict, task_mean_dict, task_std_dict):
        for key_path in task_mean_dict.keys():
            task_mean_df = calculateutil.map_flatten_df(task_mean_dict[key_path])
            task_std_df = calculateutil.map_flatten_df(task_std_dict[key_path])
            task_tb_df = calculateutil.map_flatten_df(task_tb_dict[key_path])
            scatter_plot.plot_scatter_kmeans(task_tb_df, task_mean_df, task_std_df, key_path, self.task_bean.task_name)
        #print("scatter plot ok!")

    def make_scatter_plot_threshold(self, task_tb_dict, task_mean_dict, task_std_dict, thread=25):
        for key_path in task_mean_dict.keys():
            task_mean_df = calculateutil.map_flatten_df(task_mean_dict[key_path])
            task_std_df = calculateutil.map_flatten_df(task_std_dict[key_path])
            task_tb_df = calculateutil.map_flatten_df(task_tb_dict[key_path])
            scatter_plot.plot_scatter_threshold(task_tb_df, task_mean_df, task_std_df, key_path, self.task_bean.task_name, threshold=thread)
        #print("scatter plot ok!")

    def make_scatter_meanslope(self, task_tb_dict, task_mean_dict, task_slope_dict, thread=25):
        for key_path in task_mean_dict.keys():
            task_mean_df = calculateutil.map_flatten_df(task_mean_dict[key_path])
            task_std_df = calculateutil.map_flatten_df(task_slope_dict[key_path])
            task_tb_df = calculateutil.map_flatten_df(task_tb_dict[key_path])
            scatter_plot.plot_scatter_threshold(task_tb_df, task_mean_df, task_std_df, key_path, self.task_bean.task_name, threshold=thread)
        #print("scatter mean slope plot ok!")

    def make_scatter_stdslope(self, task_tb_dict, task_std_dict, task_slope_dict, thread=25):
        for key_path in task_std_dict.keys():
            task_mean_df = calculateutil.map_flatten_df(task_std_dict[key_path])
            task_std_df = calculateutil.map_flatten_df(task_slope_dict[key_path])
            task_tb_df = calculateutil.map_flatten_df(task_tb_dict[key_path])
            scatter_plot.plot_scatter_threshold(task_tb_df, task_mean_df, task_std_df, key_path, self.task_bean.task_name, threshold=thread)
        #print("scatter std slope plot ok!")

    def save_tb_csv(self, task_tb_dict, task_mean_dict, task_std_dict):
        """save all mean and std
        """
        csv_path = configutil.get_csv_path(self.task_bean.task_name)
        file_name = self.task_bean.cp + "_" + self.task_bean.mp_like + "_" + self.task_bean.parent_like + "_" + self.task_bean.task_name
        for key_path in task_tb_dict.keys():
            for wf in task_tb_dict[key_path].keys():
                file_path = csv_path + "/" + wf + "/" + "csv/"
                calculateutil.make_path(file_path)
                tb_file = open(file_path + file_name + '.csv', "a", newline='')
                tb_csv = csv.writer(tb_file)
                tb_csv.writerow(['cp', 'mp', 'parent_name', 'like_name', 'wf', 'tb', "mean", "std"])
                tb_list = task_tb_dict[key_path][wf]
                mean_list = task_mean_dict[key_path][wf]
                std_list = task_std_dict[key_path][wf]

                key_list = key_path.split("/")
                for tb, mean, std in zip(tb_list, mean_list, std_list):
                    tmp_value = deepcopy(key_list)
                    tmp_value.extend([wf, tb, mean, std])
                    tb_csv.writerow(tmp_value)
                tb_file.close()
        #print("save tb's mean and std ok")