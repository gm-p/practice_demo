# -*- coding: utf-8 -*-
# @Time    :
# @Author  :
# @Email   :
# @File    : fault_bean.py
# @Software: PyCharm
# @Description:
from collections import defaultdict
import csv
from copy import deepcopy

from action import scatter_plot
from tool import configutil
from tool import calculateutil


class FaultBean:
    def __init__(self, task_bean):
        self.task_bean = task_bean

    @classmethod
    def find_fault_tb(cls, task_tb_dict, task_mean_dict, task_std_dict):
        fault_tb_dict = defaultdict(dict)
        for key_path in task_mean_dict.keys():
            task_mean_df = calculateutil.map_flatten_df(task_mean_dict[key_path])
            task_std_df = calculateutil.map_flatten_df(task_std_dict[key_path])
            task_tb_df = calculateutil.map_flatten_df(task_tb_dict[key_path])
            fault_tb = scatter_plot.get_fault_tb(task_tb_df, task_mean_df, task_std_df)
            fault_tb_dict[key_path] = fault_tb
        print("find fault tb ok!")
        return fault_tb_dict

    @classmethod
    def find_fault_tb_threshold(cls, task_tb_dict, task_mean_dict, task_std_dict):
        fault_tb_dict = defaultdict(dict)
        for key_path in task_mean_dict.keys():
            task_mean_df = calculateutil.map_flatten_df(task_mean_dict[key_path])
            task_std_df = calculateutil.map_flatten_df(task_std_dict[key_path])
            task_tb_df = calculateutil.map_flatten_df(task_tb_dict[key_path])
            fault_tb = scatter_plot.get_fault_tb_threshold(task_tb_df, task_mean_df, task_std_df)
            fault_tb_dict[key_path] = fault_tb
        print("find fault tb ok!")
        return fault_tb_dict

    def save_fault_tb(self, fault_tb_dict, mean_std_dict):
        csv_path = configutil.get_csv_path(self.task_bean.task_name)
        calculateutil.make_path(csv_path)
        file_name = self.task_bean.cp + "_" + self.task_bean.mp_like + "_" +\
                    self.task_bean.parent_like + "_" + self.task_bean.task_name
        fault_tb_file = open(csv_path + "/" + file_name + "_fault_tb.csv", "w", newline='')
        fault_tb_csv = csv.writer(fault_tb_file)
        fault_tb_csv.writerow(['cp', 'mp', 'parent_name', 'like_name', 'wf', 'tb', "mean", "std"])
        # value: fault_tb_dict[wf].append(fault_tb)
        for key_path in fault_tb_dict.keys():
            for wf_value in fault_tb_dict[key_path]:
                key_list = key_path.split("/")
                key_list.append(wf_value)
                tb_list = fault_tb_dict[key_path][wf_value]
                for tb in tb_list:
                    mean, std = mean_std_dict[key_path][wf_value][tb]
                    tmp_value = deepcopy(key_list)
                    tmp_value.extend([tb, mean, std])
                    fault_tb_csv.writerow(tmp_value)
        fault_tb_file.close()
        print("save fault tb ok")

    @classmethod
    def is_fault_tb(cls, fault_tb_dict, row):
        wf, tb, cp, mp, task_parent, task_name = row
        key_path = '/'.join([cp, mp, task_parent, task_name])
        if key_path in fault_tb_dict.keys():
            wf_dict = fault_tb_dict[key_path]
            if tb in wf_dict[wf]:
                return True
        return False
