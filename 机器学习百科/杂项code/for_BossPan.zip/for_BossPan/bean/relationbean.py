# -*- coding: utf-8 -*-
# @Time    :
# @Author  :
# @Email   :
# @File    : relationbean.py
# @Software: PyCharm
# @Description:
import pickle
import pandas as pd
import numpy as np
from tool import dbsearch, configutil
import os
os.environ['NLS_LANG'] = 'SIMPLIFIED CHINESE_CHINA.UTF8'

relation_path = './../data/relation_df_QKS'


class RelationShip(object):
    relation_df = None

    def __init__(self, task_relation_df=None):
        self.real_path = configutil.relative_path
        self.task_relation_df = task_relation_df

    @classmethod
    def get_relation_df(cls, file_syn=True):
        if file_syn:
            cls.relation_df = pickle.load(open(relation_path, 'rb'))
        else:
            cls._set_relation_df()
        return cls.relation_df

    @classmethod
    def _set_relation_df_all(cls):
        """

        :return: dataframe [wf, tb, cp, mp, task_parent, task_name]
        """
        conn = dbsearch.get_conn()
        wf_dict = dbsearch.get_windfarms(conn)
        relations = list()
        for wf, wf_id in wf_dict.items():
            print('%s' % wf)
            tb_dict = dbsearch.get_tubines(conn, wf_id)
            for tb, tb_id in tb_dict.items():
                cp_dict = dbsearch.get_components(conn, tb_id)
                for cp, cp_id in cp_dict.items():
                    mp_dict = dbsearch.get_meanpoints(conn, tb_id, cp_id)
                    for mp, mp_id in mp_dict.items():
                        task_parent_dict = dbsearch.get_task_parents(conn, tb_id, mp_id)
                        for task_parent, task_parent_id in task_parent_dict.items():
                            task_name_dict = dbsearch.get_task_names(conn, tb_id, mp_id, task_parent_id)
                            for task_name in task_name_dict.keys():
                                tmp_relation = [wf, tb, cp, mp, task_parent, task_name]
                                relations.append(tmp_relation)
                            if not task_name_dict:
                                tmp_relation = [wf, tb, cp, mp, task_parent, '']
                                relations.append(tmp_relation)
        relations = np.array(relations)
        cls.relation_df = pd.DataFrame(relations, columns=['wf', 'tb', 'cp', 'mp', 'task_parent', 'task_name'])
        cls._save_relation_df()

    @classmethod
    def _set_relation_df(cls):
        """

        :return: dataframe [wf, tb, cp, mp, task_parent, task_name]
        """
        conn = dbsearch.get_conn()
        all_wf_dict = dbsearch.get_windfarms(conn)
        wf_dict = cls._get_windfarms(all_wf_dict)
        relations = list()
        for wf, wf_id in wf_dict.items():
            print('%s' % wf)
            tb_dict = dbsearch.get_tubines(conn, wf_id)
            for tb, tb_id in tb_dict.items():
                cp_dict = dbsearch.get_components(conn, tb_id)
                for cp, cp_id in cp_dict.items():
                    mp_dict = dbsearch.get_meanpoints(conn, tb_id, cp_id)
                    for mp, mp_id in mp_dict.items():
                        task_parent_dict = dbsearch.get_task_parents(conn, tb_id, mp_id)
                        for task_parent, task_parent_id in task_parent_dict.items():
                            task_name_dict = dbsearch.get_task_names(conn, tb_id, mp_id, task_parent_id)
                            for task_name in task_name_dict.keys():
                                tmp_relation = [wf, tb, cp, mp, task_parent, task_name]
                                relations.append(tmp_relation)
                            if not task_name_dict:
                                tmp_relation = [wf, tb, cp, mp, task_parent, '']
                                relations.append(tmp_relation)
        relations = np.array(relations)
        cls.relation_df = pd.DataFrame(relations, columns=['wf', 'tb', 'cp', 'mp', 'task_parent', 'task_name'])
        cls._save_relation_df()

    @classmethod
    def _get_windfarms(cls, wf_dict):
        wf_list = configutil.get_windfarams()
        remain_wf = dict()
        for wf, wf_id in wf_dict.items():
            if wf in wf_list:
                remain_wf[wf] = wf_id
        return remain_wf

    @classmethod
    def _save_relation_df(cls):
        pickle.dump(cls.relation_df, open(relation_path, "wb"), 2)
        print('relation_df save ok!')

    def _set_task_relation_df(self, cp, mp_like, parent_like, task_like):
        relation_df = RelationShip.get_relation_df()
        self.task_relation_df = relation_df.loc[(relation_df.cp == cp)
                                                & (relation_df['mp'].str.contains(mp_like))
                                                & (relation_df['task_parent'].str.contains(parent_like))
                                                & (relation_df['task_name'].str.contains(task_like))]
        print(self.task_relation_df)
        self._save_task_relation_df(mp_like, parent_like, task_like)

    def _save_task_relation_df(self, mp_like, parent_like, task_like):
        pickle.dump(self.task_relation_df, open('/data/task_df/'+ mp_like + "_" + parent_like + "_" + task_like+"_relation_df", 'wb'), 2)
        print("{}_relation_df save ok!".format(task_like))

    def get_task_relation_df(self,  cp, mp_like, parent_like, task_like, file_syn=True):
        if file_syn:
            self.task_relation_df = pickle.load(open(self.real_path + '/data/task_df/' + mp_like + "_" + parent_like + "_" + task_like+"_relation_df", 'rb'))
        else:
            self._set_task_relation_df(cp, mp_like, parent_like, task_like)
        return self.task_relation_df


if __name__ == "__main__":
    relation = RelationShip()
    relation.get_relation_df(file_syn=False)
    # relation.get_relation_df(file_syn=True)
    # CF
    relation.get_task_relation_df("GB", "高速轴", "VEL", "CF", file_syn=False)
    relation.get_task_relation_df("GEN", "GEN_DE", "VEL", "CF", file_syn=False)
    # TSD
    relation.get_task_relation_df("GB", "高速轴", "ENV", "TSD", file_syn=False)
    relation.get_task_relation_df("GB", "中间轴", "ENV", "TSD", file_syn=False)
    # BDF
    relation.get_task_relation_df("MB", "主轴", "ENV", "BDF", file_syn=False)
    relation.get_task_relation_df("GEN", "GEN", "ENV", "BDF", file_syn=False)
    # SER
    relation.get_task_relation_df("GB", "高速轴", "ACC", "SER", file_syn=False)
    relation.get_task_relation_df("GB", "中间轴", "ACC", "SER", file_syn=False)
    relation.get_task_relation_df("GB", "行星级", "ACC", "SER", file_syn=False)
    # RMS
    relation.get_task_relation_df("MB", "主轴", "ENV", "RMS", file_syn=False)
    relation.get_task_relation_df("GEN", "GEN", "ENV", "RMS", file_syn=False)
    relation.get_task_relation_df("GB", "输入端", "ENV", "RMS", file_syn=False)