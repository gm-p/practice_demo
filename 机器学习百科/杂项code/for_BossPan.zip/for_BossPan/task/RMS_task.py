# -*- coding: utf-8 -*-
# @Time    :
# @Author  :
# @Email   :
# @File    : RMS_task.py
# @Software: PyCharm
# @Description: 主轴、电机 主要作用：
from bean.task_bean import TaskStatistics
from task.task_object import TaskObj


class RMSTask(TaskObj):
    def __init__(self):
        MB_task = TaskStatistics("MB", "主轴", "ENV", "RMS")
        GEN_task = TaskStatistics("GEN", "GEN", "ENV", "RMS")
        IMS_task = TaskStatistics("GB", "输入端", "ENV", "RMS")
        self.task_list = [MB_task, GEN_task, IMS_task]

    def __str__(self):
        return "RMSTask"
