# -*- coding: utf-8 -*-
# @Time    :
# @Author  :
# @Email   :
# @File    : BDR_task.py
# @Software: PyCharm
# @Description:
from bean.task_bean import TaskStatistics
from bean import BDR_bean
from bean.scatter_bean import ScatterBean


class BDRTask:
    def __init__(self):
        self.task_list = None

    #  cp, mp_like, parent_like, task_name
    def save_rawdata(self):
        raw_data_1 = BDR_bean.get_raw_data_file(BDR_bean.MB_BDF_task, 'BDF')
        raw_data_2 = BDR_bean.get_raw_data_file(BDR_bean.MB_RMS_task, 'RMS')
        BDR_bean.combine_raw_data(raw_data_1, raw_data_2, 'BDR')
        BDR_bean.save_relation_df(raw_data_1, raw_data_2, ["主轴", "ENV", "BDR"])
        MB_task = TaskStatistics("MB", "主轴", "ENV", "BDR")
        self.task_list = [MB_task]

    def make_scatter_task(self, obj):
        scatter_obj = ScatterBean(obj)
        task_tb_dict, task_mean_dict, task_std_dict = scatter_obj.get_scatter_meanstd()
        scatter_obj.make_scatter_plot_threshold(task_tb_dict, task_mean_dict, task_std_dict, thread=1.4)
        scatter_obj.save_tb_csv(task_tb_dict, task_mean_dict, task_std_dict)

    def __str__(self):
        return "BDRTask"