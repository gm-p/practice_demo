# -*- coding: utf-8 -*-
# @Time    :
# @Author  :
# @Email   :
# @File    : TSD_task.py
# @Software: PyCharm
# @Description:  中间轴、高速轴 （输入端、中间端等待因子配置正确），主要作用：
from bean.task_bean import TaskStatistics
from task.task_object import TaskObj


class TSDTask(TaskObj):
    def __init__(self):
        HSS_task = TaskStatistics("GB", "高速轴", "ENV", "TSD")
        GEN_task = TaskStatistics("GB", "中间轴", "ENV", "TSD")
        self.task_list = [HSS_task, GEN_task]

    def __str__(self):
        return "TSDTask"
