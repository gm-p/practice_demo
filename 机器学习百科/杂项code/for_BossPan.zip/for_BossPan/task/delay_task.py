# -*- coding: utf-8 -*-
# @Time    :
# @Author  :
# @Email   :
# @File    : delay_task.py
# @Software: PyCharm
# @Description:
import pickle
import pandas as pd

from tool import dbsearch
from tool import configutil


def get_task_names():
    # CF_1 = ["GB", "高速轴", "VEL", "CF"]
    # CF_2 = ["GEN", "GEN_DE", "VEL", "CF"]
    # # TSD
    # TSD_1 = ["GB", "高速轴", "ENV", "TSD"]
    # TSD_2 = ["GB", "中间轴", "ENV", "TSD"]
    # # BDF
    # BDF_1 = ["MB", "主轴", "ENV", "BDF"]
    # BDF_2 = ["GEN", "GEN", "ENV", "BDF"]
    # # SER
    # SER_1 = ["GB", "高速轴", "ACC", "SER"]
    # SER_2 = ["GB", "中间轴", "ACC", "SER"]
    # SER_3 = ["GB", "形星级", "ACC", "SER"]
    # # RMS
    # RMS_1 = ["MB", "主轴", "ENV", "RMS"]
    # RMS_2 = ["GEN", "GEN", "ENV", "RMS"]
    RMS_3 = ["GB", "输入端", "ENV", "RMS"]
    # task_list = [CF_1, CF_2, TSD_1, TSD_2, BDF_1, BDF_2, SER_1, SER_2, SER_3, RMS_1, RMS_2]
    task_list = [RMS_3]
    task_name_list = task_list
    return task_name_list


def get_wf_netinfo():
    """get wf online or outline from oracle sql
    :return wf_net_info {name, net_label} type:DataFrame
    """
    all_wf = configutil.get_windfarams()
    conn = dbsearch.get_conn()
    wf_net_info = dbsearch.get_wf_netinfo(conn, all_wf)
    return wf_net_info


def filter_delay_tb(wf, delay_days, wf_net_info):
    """ filter base rules:
        1、if online: delay_days > 3 days
        2、if outline: delay_days > 8 days
    :return boolean true: delay false: normal
    """
    net_label = wf_net_info[wf_net_info.NAME == wf]['NET_LABEL']
    net_label = str(net_label.tolist()[0])
    delay_day = delay_days.days
    if (net_label == '3') and (delay_day > 2):
        delay_syn = True
    elif (net_label == '8') and (delay_day > 7):
        delay_syn = True
    else:
        delay_syn = False
    return delay_syn, net_label


def get_task_time(task_list):
    """get task  data's time
    :return time_list:{[wf, tb, cp, mp, task_parent, task_name, task_time, T_time]
    """
    filename = '_'.join(task_list[1:])
    task_df = pickle.load(open("./../data/task_df/" + filename + "_relation_df", 'rb'))
    conn = dbsearch.get_conn()
    time_list = list()
    for index, row in task_df.iterrows():
        wf, tb, cp, mp, task_parent, task_name = row
        task_time = dbsearch.get_task_update_time(conn, wf, tb, cp, mp, task_parent, task_name)
        T_time = dbsearch.get_T_update_time(conn, wf, tb, cp, mp)
        try:
            cha_time = T_time - task_time
        except:
            print("time error", wf, tb, cp, mp, task_parent, task_name)
            continue
        time_list.append([wf, tb, cp, mp, task_parent, task_name, task_time, T_time, cha_time])
    return time_list


def filter_delay_tbs(time_list, wf_net_info):
    remainder_list = list()
    for item in time_list:
        tmp_syn, net_label = filter_delay_tb(item[0], item[-1], wf_net_info)
        if tmp_syn:
            item.append(net_label)
            remainder_list.append(item)
    return remainder_list


def get_task_times(task_name_list):
    all_time = list()
    for task_list in task_name_list:
        print("task_list", task_list)
        time_list = get_task_time(task_list)
        remainder_list = filter_delay_tbs(time_list, wf_net_info=get_wf_netinfo())
        all_time.extend(remainder_list)
    time_df = pd.DataFrame(all_time, columns=['wf', 'tb', 'cp', 'mp', 'task_parent',
                                               'task_name', 'task_time', 'T_time','T-task', 'net_label'])
    return time_df


def save_delay_task(time_df):
    """save task which task's time not equal T's time"""
    time_df.to_csv(open("./../data/csv/delay_time_2018.09.14.csv", 'w'), )
    print("save delay task data ok !!!")


def load_time_df():
    time_df = pickle.load( open("./../data/time_df", 'rb'))
    return time_df


def save_time_df(time_df):
    pickle.dump(time_df, open("./../data/time_df", 'wb'), 2)
    print("save time df ok !!!")


if __name__ == "__main__":
    import time
    start = time.time()
    task_name_list = get_task_names()
    all_time = get_task_times(task_name_list)
    # save_time_df(all_time)
    save_delay_task(all_time)
    # time_df = load_time_df()
    # save_delay_task(time_df)
    print("time", time.time() - start)