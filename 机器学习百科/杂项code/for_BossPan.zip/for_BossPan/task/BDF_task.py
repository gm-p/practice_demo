# -*- coding: utf-8 -*-
# @Time    :
# @Author  :
# @Email   :
# @File    : BDF_task.py
# @Software: PyCharm
# @Description:
from bean.task_bean import TaskStatistics
from task.task_object import TaskObj


class BDFTask(TaskObj):
    def __init__(self):
        MB_task = TaskStatistics("MB", "主轴", "ENV", "BDF")  # BDR替换
        GEN_task = TaskStatistics("GEN", "GEN", "ENV", "BDF")  # 25, 55
        self.task_list = [MB_task, GEN_task]

    def __str__(self):
        return "BDFTask"


if __name__ == "__main__":
    b = BDFTask()
    for task in b.task_list:
        b.save_rawdata(task)
        b.make_scatter_task(task)