# -*- coding: utf-8 -*-
# @Time    :
# @Author  :
# @Email   :
# @File    : remainder_task.py
# @Software: PyCharm
# @Description: 统计没有配置因子的风机
import pickle
import pandas as pd

relation_df = pickle.load(open("./../data/relation_df_2", 'rb'))


def get_lack_tb(task_list):
    """lack tb
    lack_data: [wf, tb, cp, mp, parent_task, task_name, lack]
    :param task_list : ["GB", "高速轴", "VEL", "CF"]
    """
    filename = '_'.join(task_list[1:])
    cp, mp, task_parent, task_name = task_list
    task_df = pickle.load(open("./../data/task_df/"+filename+"_relation_df", 'rb'))
    if task_df.empty: raise ValueError("task df is empty!!")
    all_wf = set(relation_df.wf)
    lack_data = list()
    for wf_item in all_wf:
        task_tb = set(task_df[task_df.wf == wf_item]['tb'])
        relation_tb = set(relation_df[relation_df.wf == wf_item]['tb'])
        diff_tb = relation_tb.difference(task_tb)
        for tb_item in relation_tb:
            row_item = [wf_item, tb_item, cp, mp, task_parent, task_name]
            if tb_item in diff_tb:
                lack_data.append(row_item)
    return lack_data


def get_lack_tbs(task_name_list):
    """task_list: [gen_cf, gen_bdf, ....]
        lack_df : pd.DataFrame
    """
    all_lack = list()
    for task_name in task_name_list:
        lack_data = get_lack_tb(task_name)
        all_lack.extend(lack_data)
    all_lack_df = pd.DataFrame(all_lack, columns=['wf', 'tb', 'cp', 'mp', 'task_parent', 'task_name'])
    return all_lack_df


def get_task_names():
    CF_1 = ["GB", "高速轴", "VEL", "CF"]
    CF_2 = ["GEN", "GEN_DE", "VEL", "CF"]
    # TSD
    TSD_1 = ["GB", "高速轴", "ENV", "TSD"]
    TSD_2 = ["GB", "中间轴", "ENV", "TSD"]
    # BDF
    BDF_1 = ["MB", "主轴", "ENV", "BDF"]
    BDF_2 = ["GEN", "GEN", "ENV", "BDF"]
    # RMS
    RMS_1 = ["MB", "主轴", "ENV", "RMS"]
    RMS_2 = ["GEN", "GEN", "ENV", "RMS"]
    RMS_3 = ["GB", "输入端", "ENV", "RMS"]

    # SER
    SER_1 = ["GB", "高速轴", "ACC", "SER"]
    SER_2 = ["GB", "中间轴", "ACC", "SER"]
    SER_3 = ["GB", "行星级", "ACC", "SER"]

    task_list = [CF_1, CF_2, TSD_1, TSD_2, BDF_1, BDF_2, SER_1, SER_2, SER_3, RMS_1, RMS_2, RMS_3]
    # task_list = [SER_3]
    task_name_list = task_list
    return task_name_list


def save_lack_task(lack_df):
    """save lack task tb
        csv: [wf, tb, cp, mp, parent_task, task_name, lack]
    """
    lack_df.to_csv(open("./../data/csv/lack_task_2018.09.13.csv", 'w'))
    print("save lack task ok !!")


def save_lack_df(lack_df):
    pickle.dump(lack_df, open("./../data/lack_df", 'wb'), 2)
    print("save lack df ok !!!")


if __name__ == "__main__":
    task_name_list = get_task_names()
    lack_df = get_lack_tbs(task_name_list)
    save_lack_task(lack_df)
    save_lack_df(lack_df)