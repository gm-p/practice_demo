# -*- coding: utf-8 -*-
# @Time    :
# @Author  :
# @Email   :
# @File    : SER_task.py
# @Software: PyCharm
# @Description: 边带能量，形星级、中间轴、高速轴，主要作用：
from bean.task_bean import TaskStatistics
from task.task_object import TaskObj


class SERTask(TaskObj):
    def __init__(self):
        HSS_task = TaskStatistics("GB", "高速轴", "ACC", "SER")
        IMS_task = TaskStatistics("GB", "中间轴", "ACC", "SER")
        PL_task = TaskStatistics("GB", "行星级", "ACC", "SER")
        self.task_list = [HSS_task, IMS_task, PL_task]

    def __str__(self):
        return "SERTask"