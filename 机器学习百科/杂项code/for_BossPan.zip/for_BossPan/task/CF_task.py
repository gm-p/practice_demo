# -*- coding: utf-8 -*-
# @Time    :
# @Author  :
# @Email   :
# @File    : CF_task.py
# @Software: PyCharm
# @Description: 高速轴、GEN，主要作用：
from bean.task_bean import TaskStatistics
from task.task_object import TaskObj


class CFTask(TaskObj):
    def __init__(self):
        HSS_task = TaskStatistics("GB", "高速轴", "VEL", "CF")
        GEN_task = TaskStatistics("GEN", "GEN_DE", "VEL", "CF")
        self.task_list = [HSS_task, GEN_task]

    def __str__(self):
        return "CFTask"
