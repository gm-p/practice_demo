# -*- coding: utf-8 -*-
# @Time    :
# @Author  :
# @Email   :
# @File    : task_object.py
# @Software: PyCharm
# @Description:
from bean.scatter_bean import ScatterBean


class TaskObj:

    def save_rawdata(self, obj):
        obj.save_task_data(gs_bool=False)
        print("%s: save rawdata ok !" % obj)

    def make_scatter_task(self, obj):
        scatter_obj = ScatterBean(obj)
        task_tb_dict, task_mean_dict, task_std_dict = scatter_obj.get_scatter_meanstd()
        scatter_obj.make_scatter_plot(task_tb_dict, task_mean_dict, task_std_dict)
        scatter_obj.save_tb_csv(task_tb_dict, task_mean_dict, task_std_dict)
        print("%s: make scatter task ok" % obj)

    def make_scatter_task_thelta(self, obj, thelta):
        scatter_obj = ScatterBean(obj)
        task_tb_dict, task_mean_dict, task_std_dict = scatter_obj.get_scatter_meanstd()
        scatter_obj.make_scatter_plot_threshold(task_tb_dict, task_mean_dict, task_std_dict)
        scatter_obj.save_tb_csv(task_tb_dict, task_mean_dict, task_std_dict)
        print("%s: make scatter task thelta ok" % obj)