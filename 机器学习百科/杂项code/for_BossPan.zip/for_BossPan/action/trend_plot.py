# -*- coding: utf-8 -*-
# @Time    :
# @Author  :
# @Email   :
# @File    : trend_plot.py
# @Software: PyCharm
# @Description:
import time
import pandas as pd
import numpy as np
from pandas.tseries.offsets import Day
import matplotlib as mpl
from matplotlib import pyplot as plt
# import statsmodels.api as sm
from tool import calculateutil, configutil

mpl.rcParams['font.sans-serif'] = ['SimHei']
mpl.rcParams['axes.unicode_minus'] = False


def split_trend_date(value_df, windows=7, interval=3):
    """

    :param value_df: columns=[value, timestamp, genspeed]
    :param windows:
    :param interval:
    :return:  [[win_value], []]
    """
    end_time = value_df['timestamp'][0]
    start_time = end_time
    window_values = list()
    while start_time >= value_df["timestamp"][-1]:
        start_time = end_time - windows*Day()
        filter_df = value_df[(value_df['timestamp'] > start_time) & (value_df['timestamp'] < end_time)]
        values = list(filter_df['value'])
        window_values.append(values)
        end_time = end_time - interval*Day()
    return window_values


def plot_mean_std_plot(trend_mean_dict, trend_std_dict, key_path, task_name):
    save_root = configutil.get_photo_path(task_name) + "trend_meanstd"
    for tb, mean_list in trend_mean_dict.iteritems():
        std_list = trend_std_dict[tb]
        plt.plot(mean_list, color='orangered', label='mean')
        plt.plot(std_list, color='cornflowerblue', label='std')
        plt.legend(loc='best')
        plt.title(key_path+'/'+tb+'_' + "trend_plot")
        plt.xlabel('ts')
        plt.ylabel('value')
        plt.savefig(save_root + tb+'.png', dpi=200)
        plt.close()


def plot_trend_decomposition(trend_value_dict, key_path, task_name):
    save_root = configutil.get_photo_path(task_name) + "trend_value"
    start_day = time.strftime("%d/%m/%Y")
    for tb, value_list in trend_value_dict.iteritems():
        ts_index = pd.date_range(start_day, periods=len(value_list), freq='D')
        k_value_df = pd.DataFrame(value_list, index=ts_index)
        s = sm.tsa.seasonal_decompose(k_value_df)
        plot_value = [x[0] for x in np.array(s.trend).tolist()]
        plt.plot(plot_value, color='orangered')
        plt.title(key_path+'/'+tb+'_' + "trend_plot")
        plt.xlabel('ts')
        plt.ylabel('value')
        plt.savefig(save_root + tb+'.png', dpi=200)
        plt.close()


def smooth_section_data(all_value, sec_num=100):
    lens = len(all_value)
    winds = lens/sec_num
    winds_value = []
    indexs = 0
    if winds == 0:
        return all_value
    for i in range(winds, len(all_value), winds):
        tmp_value = calculateutil.remove_multi_std(all_value[indexs:i])
        tmp_mean = np.mean(np.array(tmp_value))
        winds_value.append(tmp_mean)
        indexs = i
    return winds_value


def difference(all_value, interval=3):
    diff = []
    for i in range(interval, len(all_value)):
        value = all_value[i] - all_value[i - interval]
        diff.append(value)
    return diff
