# -*- coding: utf-8 -*-
# @Time    :
# @Author  :
# @File    :
# @Software: PyCharm
# @Description:
import numpy as np
from sklearn.cluster import KMeans
import matplotlib as mpl
from matplotlib import pyplot as plt
from collections import defaultdict
from tool import configutil, calculateutil

mpl.rcParams['font.sans-serif'] = ['SimHei']
mpl.rcParams['axes.unicode_minus'] = False


def get_plot_path(task_name, plot_kind):
    plot_path = configutil.get_photo_path(task_name) + plot_kind + '/'
    return plot_path


def plot_scatter_kmeans(task_tb_df, task_mean_df, task_std_df, key_path, task_name):
    plot_kind = "scatter_kmeans"
    save_path = (get_plot_path(task_name, plot_kind))
    list_path = key_path.split("/")
    file_name = "+".join(list_path[2:])
    calculateutil.make_path(save_path)
    for wf in set(task_mean_df.category):
        mean_list = list(task_mean_df[task_mean_df.category == wf]['value'])
        std_list = list(task_std_df[task_std_df.category == wf]['value'])
        tb_list = list(task_tb_df[task_tb_df.category == wf]['value'])
        if len(tb_list) <= 1: continue
        wf_meanstd = np.array(list(zip(mean_list, std_list)))
        res = KMeans(n_clusters=2).fit_predict(wf_meanstd)
        plt.scatter(wf_meanstd[:, 0], wf_meanstd[:, 1], c=res)
        for i in range(0, len(res)):
            plt.text(mean_list[i], std_list[i], tb_list[i][-3:], size=5,
                     family="fantasy", color="black", style="oblique", weight="light")
        tmp_path = save_path + "/" + wf
        calculateutil.make_path(tmp_path)
        calculateutil.make_path(save_path)
        plt.title(key_path + '/' + wf + '_' + plot_kind)
        plt.xlabel('mean')
        plt.ylabel('std')
        plt.savefig(tmp_path+'/' + file_name +'.png', dpi=200)
        plt.close()


def get_fault_tb(task_tb_df, task_mean_df, task_std_df):
    fault_tb_dict = defaultdict(list)
    for wf in set(task_mean_df.category):
        mean_list = list(task_mean_df[task_mean_df.category == wf]['value'])
        std_list = list(task_std_df[task_std_df.category == wf]['value'])
        tb_list = list(task_tb_df[task_tb_df.category == wf]['value'])
        if len(tb_list) <= 1:
            continue
        wf_meanstd = np.array(list(zip(mean_list, std_list)))
        res = KMeans(n_clusters=2).fit_predict(wf_meanstd)
        if np.mean(np.array(wf_meanstd[res == 0][:, 0])) > np.mean(np.array(wf_meanstd[res == 1][:, 0])):
            fault_tb = map(lambda i: tb_list[i] if res[i] == 0 else None,  range(0, len(res)))
            fault_tb = filter(lambda x: x, fault_tb)
        else:
            fault_tb = map(lambda i: tb_list[i] if res[i] == 1 else None, range(0, len(res)))
            fault_tb = filter(lambda x: x, list(fault_tb))
        fault_tb_dict[wf].extend(list(fault_tb))
    return fault_tb_dict


def plot_scatter_threshold(task_tb_df, task_mean_df, task_std_df, key_path, task_name, threshold=30):
    plot_kind = "scatter_kmeans"
    save_path = (get_plot_path(task_name, plot_kind))
    list_path = key_path.split("/")
    file_name = "+".join(list_path[2:])
    calculateutil.make_path(save_path)
    for wf in set(task_mean_df.category):
        mean_list = list(task_mean_df[task_mean_df.category == wf]['value'])
        std_list = list(task_std_df[task_std_df.category == wf]['value'])
        tb_list = list(task_tb_df[task_tb_df.category == wf]['value'])
        if len(tb_list) <= 1: continue
        wf_meanstd = np.array(list(zip(mean_list, std_list)))
        # res = KMeans(n_clusters=2).fit_predict(wf_meanstd)
        res = list()
        for mean_item in mean_list:
            single = 0 if mean_item < threshold else 1
            res.append(single)
        plt.scatter(wf_meanstd[:, 0], wf_meanstd[:, 1], c=res)
        for i in range(0, len(res)):
            plt.text(mean_list[i], std_list[i], tb_list[i][-3:], size=5,
                     family="fantasy", color="black", style="oblique", weight="light")
        tmp_path = save_path + "/" + wf
        calculateutil.make_path(tmp_path)
        calculateutil.make_path(save_path)
        plt.title(key_path + '/' + wf + '_' + plot_kind)
        plt.xlabel('mean')
        plt.ylabel('std')
        plt.savefig(tmp_path+'/' + file_name +'.png', dpi=200)
        plt.close()


def get_fault_tb_threshold(task_tb_df, task_mean_df, task_std_df, threshold=30):
    fault_tb_dict = defaultdict(list)
    for wf in set(task_mean_df.category):
        mean_list = list(task_mean_df[task_mean_df.category == wf]['value'])
        std_list = list(task_std_df[task_std_df.category == wf]['value'])
        tb_list = list(task_tb_df[task_tb_df.category == wf]['value'])
        if len(tb_list) <= 1:
            continue
        wf_meanstd = np.array(list(zip(mean_list, std_list)))
        res = list()
        for mean_item in mean_list:
            single = 0 if mean_item < threshold else 1
            res.append(single)
        if np.mean(np.array(wf_meanstd[res == 0][:, 0])) > np.mean(np.array(wf_meanstd[res == 1][:, 0])):
            fault_tb = map(lambda i: tb_list[i] if res[i] == 0 else None,  range(0, len(res)))
            fault_tb = filter(lambda x: x, fault_tb)
        else:
            fault_tb = map(lambda i: tb_list[i] if res[i] == 1 else None, range(0, len(res)))
            fault_tb = filter(lambda x: x, list(fault_tb))
        fault_tb_dict[wf].extend(list(fault_tb))
    return fault_tb_dict


