# -*- coding: utf-8 -*-
# @Time    :
# @Author  :
# @File    :
# @Software: PyCharm
# @Description:
import os
import numpy as np
import seaborn as sns
import matplotlib as mpl
from matplotlib import pyplot as plt
from tool import configutil, calculateutil

mpl.rcParams['font.sans-serif'] = ['SimHei']
mpl.rcParams['axes.unicode_minus'] = False


def get_plot_path(task_name, plot_kind):
    plot_path = configutil.get_photo_path(task_name) + plot_kind +'/'
    return plot_path


def box_median(tmp_df, sns_plot):
    # add medians
    medians = tmp_df.groupby(['category'])['value'].median().values
    median_labels = [str(np.round(s, 2)) for s in medians]
    pos = range(len(medians))
    for tick, label in zip(pos, sns_plot.get_xticklabels()):
        sns_plot.text(pos[tick], medians[tick], median_labels[tick], horizontalalignment='center',
                      size='x-small', color='black', weight='semibold')
    return sns_plot


def plot_sns_plot(wf_value_df, key_path, task_name, plot_kind):
    """
    :param wf_value_df:  [wf, value]
    :param key_path: cp/mp/task_parent/task_name
    :param task_name: BDF/CF/TSD
    :param task_name; boxplot/distplot/violinplot/
    :return:
    """
    save_path = (get_plot_path(task_name, plot_kind) + key_path).decode('utf-8')
    calculateutil.make_path(save_path)
    for wf in set(wf_value_df.category):
        tmp_df = wf_value_df[wf_value_df['category'] == wf]
        if plot_kind == 'boxplot':
            sns_plot = sns.boxplot(x='category', y='value', data=tmp_df)
            sns_plot = box_median(tmp_df, sns_plot)
        elif plot_kind == 'distplot':
            sns_plot = sns.distplot(np.array(tmp_df['value']), bins=20, kde=True)
        elif plot_kind == 'violinplot':
            sns_plot = sns.violinplot(x='category', y='value', data=tmp_df )
        plt.title(key_path+'/'+wf+'_' + plot_kind)
        plt.xlabel('wf_name')
        plt.ylabel(task_name+'_value')
        fig = sns_plot.get_figure()
        fig.savefig(save_path+'/' + wf + '.png', dpi=200)
        print("plot {}  ok !".format(plot_kind))
        plt.close()
