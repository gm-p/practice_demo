# -*- coding: utf-8 -*-

TRAIN_PATH = '../../data/train/'

TEST_PATH = '../../data/test/'

LABEL_PATH = '../../data/train_labels.csv'

SUBMIT_SAMPLE_PATH = '../../data/submit_example.csv'

SAVE_PATH = '../../result.csv'