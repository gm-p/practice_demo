#!/bin/bash
#1.A
cd A
bash run.sh
cd ..

#2.gdy
cd gdy
bash run.sh
cd ..

#3.wh
cd wh
bash run.sh
cd ..

#4.lyy
cd lyy
bash run.sh
cd ..