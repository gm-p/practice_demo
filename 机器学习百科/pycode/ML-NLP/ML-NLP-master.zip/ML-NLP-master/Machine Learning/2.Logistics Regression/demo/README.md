## Kaggle上简单的金融信用分类，代码都有注释，此处不再赘述！
[CreditScoring.ipynb](https://github.com/NLP-LOVE/ML-NLP/blob/master/Machine%20Learning/2.Logistics%20Regression/demo/CreditScoring.ipynb)
