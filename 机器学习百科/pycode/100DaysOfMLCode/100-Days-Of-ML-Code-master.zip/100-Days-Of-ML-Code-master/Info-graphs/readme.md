Each Day Infograph
